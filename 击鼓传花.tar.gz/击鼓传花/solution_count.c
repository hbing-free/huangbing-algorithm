/*
击鼓传花
solution_count.c
gcc -g3 solution_count.c -o gsolution_count_exe;
./gsolution_count_exe
gdb gsolution_count_exe
*/
//-----------------
#include<stdio.h>
#include<stdlib.h>
//----------------
int GetSolutionCount(const int n,const int m)
{
  int iret=0,i=0,j=0,iend=0,ileft=0,iright=0;
  int** pcount=(int**)calloc(n,sizeof(int*));
  int* pm=(int*)calloc(n*m,sizeof(int));
  int* const pmr=pm;
  for(i=0;i<n;i++,pm+=m)
    pcount[i]=pm;
  pcount[0][0]=0;
  pcount[1][0]=pcount[n-1][0]=1;
  for(i=2,iend=n-2;i<=iend;i++)
    pcount[i][0]=0;
  for(j=1;j<m;j++)
  {
    for(i=0;i<n;i++)
    {
      ileft=(n+i-1)%n;
      iright=(i+1)%n;
      pcount[i][j]=pcount[ileft][j-1]+pcount[iright][j-1];
    }
  }
  iret=pcount[0][m-1];
  free(pcount);
  free(pmr);
  return iret;
}
int main()
  {
    int n,m;
    int iret=scanf("%d %d",&n,&m);
    iret=GetSolutionCount(n,m);
    printf("%d\n",iret);
    return 0;
  }
  //---------------
